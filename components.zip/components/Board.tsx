import { DragOverlay } from '@dnd-kit/core';
import { snapCenterToCursor } from '@dnd-kit/modifiers';

import { Arrows } from './Arrows';
import { useChessboardContext } from './ChessBoardProvider';
import { defaultBoardStyle } from './defaults';
import { Draggable } from './Draggable';
import { Droppable } from './Droppable';
import { preventDragOffBoard } from './modifiers';
import { Piece } from './Piece';
import { Square } from './Square';

export function Board() {
  const {
    allowDragOffBoard,
    board,
    boardStyle,
    chessboardColumns,
    currentPosition,
    draggingPiece,
    id,
  } = useChessboardContext();

  return (
    <>
      <div
        id={`${id}-board`}
        style={{ ...defaultBoardStyle(chessboardColumns), ...boardStyle }}
      >
        {board.map((row) =>
          row.map((square) => {
            const piece = currentPosition[square.squareId];

            return (
              <Droppable key={square.squareId} squareId={square.squareId}>
                {({ isOver }) => (
                  <Square isOver={isOver} {...square}>
                    {piece ? (
                      <Draggable
                        isSparePiece={false}
                        position={square.squareId}
                        pieceType={piece.pieceType}
                      >
                        <Piece {...piece} position={square.squareId} />
                      </Draggable>
                    ) : null}
                  </Square>
                )}
              </Droppable>
            );
          }),
        )}

        <Arrows />
      </div>

      <DragOverlay
        dropAnimation={null}
        modifiers={[
          snapCenterToCursor,
          ...(allowDragOffBoard
            ? []
            : [preventDragOffBoard(id, draggingPiece?.position || '')]),
        ]}
      >
        {draggingPiece ? (
          <Piece
            clone
            position={draggingPiece.position}
            pieceType={draggingPiece.pieceType}
          />
        ) : null}
      </DragOverlay>
    </>
  );
}