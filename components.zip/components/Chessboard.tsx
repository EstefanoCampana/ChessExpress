import { StyleSheet } from 'react-native';
import { Board } from './Board';
import {
    ChessboardOptions,
    ChessboardProvider,
    useChessboardContext,
} from './ChessBoardProvider';

type ChessboardProps = {
  options?: ChessboardOptions;
};

export function ChessBoard({ options }: ChessboardProps) {
  const { isWrapped } = useChessboardContext() ?? { isWrapped: false };

  if (isWrapped) {
    return <Board />;
  }

  return (
    <ChessboardProvider options={options}>
      <Board />
    </ChessboardProvider>
  );
}
const styles = StyleSheet.create({
    board: {
        width: "90%",
        height: "50%",
        aspectRatio: 1,
        borderRadius: 10,
  },
})